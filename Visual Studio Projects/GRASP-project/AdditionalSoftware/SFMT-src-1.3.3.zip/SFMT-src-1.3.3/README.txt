 =================================================================
 SFMT ver. 1.3.3
 SIMD oriented Fast Mersenne Twister(SFMT)

 Mutsuo Saito (Hiroshima University) and
 Makoto Matsumoto (Hiroshima University)

 Copyright (C) 2006, 2007 Mutsuo Saito, Makoto Matsumoto and Hiroshima
 University. All rights reserved.

 The (modified) BSD License is applied to this software, see LICENSE.txt
 =================================================================

 To see documents, see html/index.html.

 To make test program, see html/howto-compile.html

 If you want to redistribute and/or change source files, see LICENSE.txt.

 When you change these files and redistribute them, PLEASE write your
 e-mail address in redistribution and write to contact YOU first if
 users of your changed source encounter troubles.
